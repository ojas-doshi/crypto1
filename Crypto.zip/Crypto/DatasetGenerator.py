from Database import Database
from datetime import datetime
from datetime import timedelta
from DataUtils import DataUtils
from DataLoader import DataLoader 

import math

class DatasetGenerator:
	def __init__(this):
		this.symbol_list= ['ETH','EOS','XRP','BCH','LTC','TRX','ETC','BNB','OKB']
		#this.symbol_list= ['ETH']
		

	def getMovement(this,perc):
		if(perc<-0.1): return "VL"
		if(perc<-.05): return "L"
		if(perc>.05): return "H"
		if(perc>0.1): return "VH"
		return "NC"


	def generateDataset(this):
		du=DataUtils()
		db=Database()

		
		d=datetime.now()
		
		print("preparing...")
		for symbol in this.symbol_list:
			d1=datetime(d.year,d.month,d.day,d.hour,math.floor(d.minute/15)*15,0,0)
				
			f = open("DataSet_"+symbol+".csv","w+")
			lastopen=None
			lastclose=None
			d2=d1
			for i in range(1000):
				dates=du.getDates(d2)
				#print(dates)
				curropen=None
				currclose=None
				for date in dates[1:]:
					max, min, close, openval=db.getValues(symbol,date[0],date[1])
					if(curropen==None):
						curropen=openval
						currclose=close
					#print(date,min,max)
					#L = str(max_15min)+","+str(min_15min)+","+str(max_1hr)+","+str(min_1hr)+","+str(max_4hr)+","+str(min_4hr)+","+str(max_1d)+","+str(min_1d)+","+str(max_1m)+","+str(min_1m)+","+str(max_6m)+","+str(min_6m)+"\n"
					f.write(str(max)+","+str(min)+",")
				if(lastopen!=None and lastclose!=None):
					print(lastclose,lastopen)
					perc=((lastclose-lastopen)/lastopen)*100
					print(perc)
					f.write(this.getMovement(perc))
				else:
					f.write("NA")
				f.write("\n")
				d2 = d2 - timedelta(minutes=15)				
				lastopen=curropen
				lastclose=currclose
			f.close()				
			
		db.close()
		print("Prepared")

print("Updating...")
#DataLoader()
print("***Data Updated***\n")
print("Now Generating DataSets...\n")
dsg=DatasetGenerator()
dsg.generateDataset()
print("DataSets Generated\n")