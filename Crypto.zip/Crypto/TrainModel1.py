# %%

#Declaring necessary modules
import tensorflow as tf
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
"""
A simple numpy implementation of a XOR gate to understand the backpropagation
algorithm
"""
classmap=dict()

# classmap["VH"]=1.0/6
# classmap["H"]=2.0/6
# classmap["NC"]=3.0/6
# classmap["L"]=4.0/6
# classmap["VL"]=5.0/6
# classmap["NA"]=6.0/6

classmap["VH"]=[1,0,0,0,0,0]
classmap["H"]=[0,1,0,0,0,0]
classmap["NC"]=[0,0,1,0,0,0]
classmap["L"]=[0,0,0,1,0,0]
classmap["VL"]=[0,0,0,0,1,0]
classmap["NA"]=[0,0,0,0,0,1]

# %%
df = pd.read_csv('C://Users/Ojas Doshi/crypto/DataSet_ETC.csv')

# for i in range(1,1000):
#     df.at[i,'CLASS']=classmap[df.at[i,'CLASS']]

# print(df)

# %%
x = tf.placeholder("double",shape = [1000,22],name = "x")
#declaring a place holder for input x
y = tf.placeholder("double",shape = [1000,6],name = "y")
#declaring a place holder for desired output y
#y = df['CLASS']
# X_train, X_test, y_train, y_test = train_test_split(
#     df,
#     df['CLASS'],
#     test_size=0.2,
#     random_state=42
# )
m = np.shape(x)[0]#number of training examples
n = np.shape(x)[1]#number of features
hidden_s = 500 #number of nodes in the hidden layer
l_r = 1#learning rate initialization

theta1 = tf.cast(tf.Variable(tf.random_normal([23,hidden_s]),name = "theta1"),tf.float64)
theta2 = tf.cast(tf.Variable(tf.random_normal([hidden_s+1,1]),name = "theta2"),tf.float64)

#conducting forward propagation
a1 = tf.concat([np.c_[np.ones(x.shape[0])],x],1)
#the weights of the first layer are multiplied by the input of the first layer

z1 = tf.matmul(a1,theta1)
#the input of the second layer is the output of the first layer, passed through the activation function and column of biases is added

a2 = tf.concat([np.c_[np.ones(x.shape[0])],tf.sigmoid(z1)],1)
#the input of the second layer is multiplied by the weights

z3 = tf.matmul(a2,theta2)
#the output is passed through the activation function to obtain the final probability

h3 = tf.sigmoid(z3)
cost_func = -tf.reduce_sum(y*tf.log(h3)+(1-y)*tf.log(1-h3),axis = 1)

#built in tensorflow optimizer that conducts gradient descent using specified    learning rate to obtain theta values

optimiser = tf.train.GradientDescentOptimizer(learning_rate = l_r).minimize(cost_func)


# %%
#setting required X and Y values to perform XOR operation
X = df.loc[:,'A1':'A22']

# %%
Y = df.loc[:,'CLASS1':'CLASS6']


# %%
#initializing all variables, creating a session and running a tensorflow session
init = tf.global_variables_initializer()
sess = tf.Session()
sess.run(init)

#running gradient descent for each iteration and printing the hypothesis    obtained using the updated theta values
for i in range(100000):
   sess.run(optimiser, feed_dict = {x:X,y:Y})#setting place holder values using feed_dict
   if i%10000==0:
      print("Epoch:",i)
      print("Hyp:",sess.run(h3,feed_dict = {x:X,y:Y}))

 # %%


