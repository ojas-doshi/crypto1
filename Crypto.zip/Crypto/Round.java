import java.util.Scanner;


public class Round {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter total no. of records :");
		int n = sc.nextInt();
		String [] records = new String[n];
		sc.nextLine();
		for(int i = 0 ; i < n ; i++ )
		{
			records[i] = sc.nextLine();
		}
		System.out.print("Enter total Disks : ");
		int p = sc.nextInt();
		int r = 0;
		if(n % p == 0 )
			r = n/p;
		else
			r = n/p +1 ;
		
		String [] disks = new String[n];
		int ctr=0;
		for(int i = 0 ; i < p ; i++)
		{
			for(int j = i ; j < n ; j = j+r )
			{
				disks[j] = records[ctr++];
			}
		}
		ctr = 1 ;
		for(int i = 0 ; i < n ; i++ )
		{
			if((i)%p == 0 )
				System.out.println("Disk : " + ctr++ +"->" );
			System.out.println(disks[i]);
		}
	}

}
