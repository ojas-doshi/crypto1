import json
import requests
import mysql.connector
mydb = mysql.connector.connect(
    host = "127.0.0.1",
    user = "root",
    passwd = "root",
    database = "sample"
)
mycursor = mydb.cursor(prepared=True)
sql = """select * from entry_hash"""
mycursor.execute(sql)
records =[]
records+=mycursor.fetchall()
mycursor.execute("""select partition_name,table_rows from information_schema.partitions where table_name='entry_hash'""")
partition=[]
partition+=mycursor.fetchall()
s = 0
for i in range(0,4):
    e=s+partition[i][1]
    for j in range(s,e):
        print(records[j])
    s =s+partition[i][1]
    print("\n\n")